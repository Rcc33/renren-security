package io.renren.modules.doc_manage.dao;

import io.renren.modules.doc_manage.entity.DocCatalogEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 档案大类
 * 
 * @author liumingming
 * @email liumingming@nankai.edu.cm
 * @date 2021-08-07 10:20:20
 */
@Mapper
public interface DocCatalogDao extends BaseMapper<DocCatalogEntity> {
	
}
