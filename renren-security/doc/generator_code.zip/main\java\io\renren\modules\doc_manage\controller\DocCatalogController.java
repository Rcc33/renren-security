package io.renren.modules.doc_manage.controller;

import java.util.Arrays;
import java.util.Map;

import io.renren.common.validator.ValidatorUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.renren.modules.doc_manage.entity.DocCatalogEntity;
import io.renren.modules.doc_manage.service.DocCatalogService;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;



/**
 * 档案大类
 *
 * @author liumingming
 * @email liumingming@nankai.edu.cm
 * @date 2021-08-07 10:20:20
 */
@RestController
@RequestMapping("doc_manage/doccatalog")
public class DocCatalogController {
    @Autowired
    private DocCatalogService docCatalogService;

    /**
     * 列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("doc_manage:doccatalog:list")
    public R list(@RequestParam Map<String, Object> params){
        PageUtils page = docCatalogService.queryPage(params);

        return R.ok().put("page", page);
    }


    /**
     * 信息
     */
    @RequestMapping("/info/{catalogId}")
    @RequiresPermissions("doc_manage:doccatalog:info")
    public R info(@PathVariable("catalogId") Long catalogId){
        DocCatalogEntity docCatalog = docCatalogService.getById(catalogId);

        return R.ok().put("docCatalog", docCatalog);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    @RequiresPermissions("doc_manage:doccatalog:save")
    public R save(@RequestBody DocCatalogEntity docCatalog){
        docCatalogService.save(docCatalog);

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("doc_manage:doccatalog:update")
    public R update(@RequestBody DocCatalogEntity docCatalog){
        ValidatorUtils.validateEntity(docCatalog);
        docCatalogService.updateById(docCatalog);
        
        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("doc_manage:doccatalog:delete")
    public R delete(@RequestBody Long[] catalogIds){
        docCatalogService.removeByIds(Arrays.asList(catalogIds));

        return R.ok();
    }

}
